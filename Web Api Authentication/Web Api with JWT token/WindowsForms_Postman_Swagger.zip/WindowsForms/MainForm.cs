
// A minimal Windows Forms example to login and fetch products
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace TokenAuthClient
{
    public partial class MainForm : Form
    {
        private string token = "";

        public MainForm()
        {
            InitializeComponent();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            var client = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(new {
                username = txtUsername.Text,
                password = txtPassword.Text
            }), Encoding.UTF8, "application/json");

            var response = await client.PostAsync("https://localhost:5001/api/auth/login", content);
            var result = await response.Content.ReadAsStringAsync();
            var obj = JObject.Parse(result);
            token = obj["token"]?.ToString();
            MessageBox.Show("Token received!");
        }

        private async void btnGetProducts_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(token)) return;

            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await client.GetStringAsync("https://localhost:5001/api/products");
            var products = JsonConvert.DeserializeObject<List<Product>>(response);
            listBox1.DataSource = products;
        }
    }

    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public override string ToString() => $"{Name} - ${Price}";
    }
}
